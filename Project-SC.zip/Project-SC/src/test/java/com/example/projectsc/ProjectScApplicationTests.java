package com.example.projectsc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectScApplicationTests {

    @Test
    void contextLoads() {
    }

}
