package com.example.projectsc;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.annotation.Rollback;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class BookRepositoryTests {
    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private BookRepository repo;
    @Test
    public void testCreateBook() {
        Book book = new Book();
        book.setNic("1234658974V");
        book.setEmail("ravikumar@gmail.com");
        book.setFirstName("Ravi");
        book.setLastName("Kumar");
        book.setVehicleno("67543GF");
        book.setVehicletype("Car");
        book.setMonth("10");
        book.setDay("14");
        book.setTime("11");


        Book savedBook = repo.save(book);

        Book existBook = entityManager.find(Book.class, savedBook.getId());

        assertThat(book.getEmail()).isEqualTo(existBook.getEmail());

    }
}
