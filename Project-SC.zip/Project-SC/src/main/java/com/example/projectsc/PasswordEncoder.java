package com.example.projectsc;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class PasswordEncoder {
    static void main(String[] args)
    {
       // BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        //String rawpassward="nam2020";
        //String encodedPassword = passwordEncoder.encode(rawpassward);
//System.out.println(encodedPassword);
    }
}
