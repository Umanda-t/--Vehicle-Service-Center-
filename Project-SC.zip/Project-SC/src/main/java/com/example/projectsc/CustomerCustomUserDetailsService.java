package com.example.projectsc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
/**
public class CustomerCustomUserDetailsService implements UserDetailsService {
    @Autowired
    private CustomerRepository CustomerRepo;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Customer customer = CustomerRepo.findByEgmail(username);
        if (customer == null) {
            throw new UsernameNotFoundException("User not found");
        }
        return new CustomerCustomUserDetails(customer);

    }
}
 **/
