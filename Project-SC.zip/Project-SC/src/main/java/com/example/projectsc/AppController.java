package com.example.projectsc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@Controller
public class AppController {
    @Autowired
    private UserRepository userRepo;
    @Autowired
    private CustomerRepository CustomerRepo;
    @Autowired
    private BookRepository BookRepo;

    @GetMapping("")
    public String viewHomePage() {
        return "index";
    }

    @GetMapping("/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new User());

        return "signup_form";
    }
   /** @GetMapping("/signup_form")
    public String showUserList(Model model){
        model.addAttribute("user", new User());
        return "signup_form";
    }
    **/
    @PostMapping("/process_register")
    public String processRegister(User user) {
        //model.addAttribute("user",  user);
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);

        userRepo.save(user);

        return "register_success";
    }
    @GetMapping("/users")
    public String listUsers(Model model) {
        List<User> listUsers = userRepo.findAll();
       model.addAttribute("listUsers", listUsers);
        return "users";
    }

    @GetMapping(path="/add")
    public @ResponseBody
    String addNewUser () {
        User n = new User();
        n.setFirstName("Qwew");
        n.setEmail("email");
        n.setLastName("Uttgb");
        n.setPassword("yrr45");
        userRepo.save(n);
        return "Saved";
    }
    //end of User


/**
    @GetMapping("/Customerregister")
    public String showCustomerRegistrationForm(Model model) {
        model.addAttribute("customer", new Customer());

        return "customer_signup_form";
    }
    @PostMapping("/Customer_process_register")
    public String processCustomerRegister(Customer customer) {
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(customer.getPassword());
        customer.setPassword(encodedPassword);

        CustomerRepo.save(customer);

        return "customer_register_success";
    }
**/

    //end of Cutomer


    @GetMapping("/booksregister")
    public String showBookRegistrationForm(Model model) {
        model.addAttribute("book", new Book());

        return "books";
    }
    @PostMapping("/book_process")
    public String bookprocessRegister(Book book) {
       // BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
       // String encodedPassword = passwordEncoder.encode(book.getPassword());
       // book.setPassword(encodedPassword);

        BookRepo.save(book);

        return "book_register_success";
    }
    @GetMapping("/list_Book")
    public String listBooks(Model model) {
        List<Book> listBooks = BookRepo.findAll();
        model.addAttribute("listBooks", listBooks);

        return "bookview";
    }

    //end of book
    @GetMapping("/stafflogin")
    public String showStafflogin() {
        return "stafflogin_form";
    }

    @PostMapping("/Login_Service")
    public String StaffLoginService(Model model) {
        model.addAttribute("staff", new Staff());

        return "success";
    }


}
